import React, {Component, lazy, Suspnese} from 'react';
import {Link} from 'react-router-dom';
import{


} from 'reactstrap';

import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';
import { getStyle, hexToRgba } from '@coreui/coreui/dist/js/coreui-utilities'


const brandPrimary = getStyle('--primary')
const brandSuccess = getStyle('--success')
const brandInfo = getStyle('--info')
const brandWarning = getStyle('--warning')
const brandDanger = getStyle('--danger')


class Home extends Component{

    render() {

        return(
            <div>
                <span class = "display-1">Welcome to MyPala</span>

            </div>

        );
    }
}


export default Home;